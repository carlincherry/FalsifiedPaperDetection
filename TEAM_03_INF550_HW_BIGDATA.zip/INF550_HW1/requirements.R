install.packages(c("tidyverse", "lubridate", "RSelenium", "getProxy", "jsonlite", "gtrendsR", "naniar", "factoextra", "cluster", "Rtsne", "arsenal", "gridExtra"))
